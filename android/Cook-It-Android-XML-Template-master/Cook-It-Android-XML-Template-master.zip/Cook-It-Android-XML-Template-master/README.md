# Cook It Android XML Template

<a href='https://ko-fi.com/A811KFP' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi3.png?v=0' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

Android xml layout for Cooking/Recipe App.

Refresh your app recipe with this UI Kit, clean & tasty UI by Alex Dapunt. With this Kit, you can impress your user to make it loving your app.

[Find it too on uiresource](http://uiresource.com/ui-share/recipe-app-ui-kit/)

![Splash](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-163055.png "Splash")
![Home](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162820.png "Home")
![Drawer](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162831.png "Drawer")
![Detail Recipe]https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162844.png "Detail Recipe")
![Shopping List](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162853.png "Shopping List")
![Preparation](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162900.png "Preparation")
![Share](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162912.png "Share")
![Comment](https://github.com/ahmadnurhidayat/Cook-It-Android-XML-Template/blob/master/screenshot/Screenshot_20170128-162917.png "Comment")

