package com.uiresource.cookit.recycler;

/**
 * Created by Dytstudio.
 */

public class ItemShopping {
    String name, pieces;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPieces(String pieces) {
        this.pieces = pieces;
    }

    public String getPieces() {
        return pieces;
    }
}
