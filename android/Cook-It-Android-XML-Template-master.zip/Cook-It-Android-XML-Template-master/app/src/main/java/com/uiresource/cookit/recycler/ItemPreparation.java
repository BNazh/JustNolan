package com.uiresource.cookit.recycler;

/**
 * Created by Dytstudio.
 */

public class ItemPreparation {
    String step;
    String number;

    public void setStep(String step) {
        this.step = step;
    }

    public String getStep() {
        return step;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getNumber() {
        return number;
    }
}
